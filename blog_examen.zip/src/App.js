
import React from 'react';

const Blog = () => {
  return (
    <div>
      <h1>Blog en React con Vite</h1>

      <section>
        <h2>1. Introducción</h2>
        <p>
          React es una biblioteca muy popular para hacer aplicaciones web y Vite es una herramienta que ayuda a que el desarrollo sea rápido y fácil. Juntos hacen que programar sea mucho más sencillo.
        </p>
      </section>

      <section>
        <h2>2. Configuración rápida con Vite</h2>
        <p>
          Usar Vite con React es muy fácil. Solo necesitas instalar algunas herramientas y listo. Vite hace que los cambios que hagas en el código se vean casi al instante.
        </p>
      </section>

      <section>
        <h2>3. Plugins de Vite para React</h2>
        <ul>
          <li>
            <strong>@vitejs/plugin-react:</strong> Permite que React actualice la página de manera rápida sin tener que recargar toda la aplicación.
          </li>
          <li>
            <strong>@vitejs/plugin-react-swc:</strong> Usa una herramienta más rápida para hacer el mismo trabajo que el anterior.
          </li>
        </ul>
      </section>

      <section>
        <h2>4. Recomendaciones para producción</h2>
        <p>
          Si tu proyecto va a ser grande o en producción, es buena idea usar TypeScript, que ayuda a evitar errores y hace el código más claro.
        </p>
      </section>

      <section>
        <h2>5. Conclusión</h2>
        <p>
          Con React y Vite puedes crear aplicaciones de manera rápida y fácil. Si sigues las recomendaciones, tu código será más fácil de entender y sin errores.
        </p>
      </section>
    </div>
  );
};

export default Blog;
