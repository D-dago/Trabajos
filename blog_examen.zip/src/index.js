import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Blog from './App';

ReactDOM.render(
  <React.StrictMode>
    <Blog />
  </React.StrictMode>,
  document.getElementById('root')
);